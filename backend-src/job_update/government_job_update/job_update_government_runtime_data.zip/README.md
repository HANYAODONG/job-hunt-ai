# Government runtime data

Unzip this file in:

backend-src/job_update/government_job_update/

After unzip, these files should exist:

data/base/government_job_update.db
government_jobs_2024_2026_tech_final.csv